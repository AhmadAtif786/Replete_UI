declare module 'eth-provider';
